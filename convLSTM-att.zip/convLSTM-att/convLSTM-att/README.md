
Coded by: Ye Xiaolei;
email: lexi_yxl@163.com

The model is built with the PyTorch deep learning library. It is coded in python and 
runs on Python 3.7, CUDA 11.4, and Windows with an Intel Core i7 CPU and an NVIDIA 
GeForce Mx350 GPU.

software: pycharm
run:Right click on the file and select Run

tips:If the picture appears straight,you can regulate eapoch and run it again;
you can change the train data and test data in Divide the dataset model